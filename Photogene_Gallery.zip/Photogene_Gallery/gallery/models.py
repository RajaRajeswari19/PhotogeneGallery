from django.db import models
from django.urls import reverse
from account.models import Account
from category.models import Category


# Create your models here.
class Image(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    # titleurl = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='photos/imgs')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    uploaded_by = models.ForeignKey(Account, on_delete=models.CASCADE)

    def get_url(self):
        return reverse('image_detail', args=[self.category.slug, self.title])

    def __str__(self):
        return self.title


class ImageGallery(models.Model):
    img = models.ForeignKey(Image, default=None, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='gallery/images', max_length=255)

    def __str__(self):
        return self.img.title

    class Meta:
        verbose_name = 'imagegallery'
        verbose_name_plural = 'image gallery'
