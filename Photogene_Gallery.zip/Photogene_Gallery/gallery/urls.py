from django.urls import path
from . import views

urlpatterns = [
    path('upload/', views.upload_image, name='upload_image'),
    path('search/', views.search, name='search'),
    path('', views.gallery, name='gallery'),
    path('category/<slug:category_slug>/', views.gallery, name='images_by_category'),
    path('category/<slug:category_slug>/<str:title>/', views.image_detail, name='image_detail'),
]
