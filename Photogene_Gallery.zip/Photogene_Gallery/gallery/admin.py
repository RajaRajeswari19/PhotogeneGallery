from django.contrib import admin
from .models import Image

# Register your models here.

class ImageAdmin(admin.ModelAdmin):
    #prepopulated_fields = {'slug': ('category_name',)}
    list_display = ('title', 'description','category')

admin.site.register(Image, ImageAdmin)
