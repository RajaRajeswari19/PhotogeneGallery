import datetime
from django.shortcuts import render, get_object_or_404, redirect
from account.models import Account
from gallery.forms import ImageForm
from gallery.models import Image
from category.models import Category
from django.db.models import Q

from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import HttpResponse

# Create your views here.
def search(request):
    if 'keyword' in request.GET:
        keyword = request.GET['keyword']
        if keyword:
            images = Image.objects.order_by('-uploaded_at').filter(Q(title__icontains=keyword) | Q(description__icontains=keyword) | Q(category__category_name__icontains=keyword) )
            images_count = images.count()
            
    context = {
        'images': images,
        'imagescount' : images_count
    }
    return render(request, 'gallery/image.html', context)

def image_detail(request, category_slug, title):
    try:
        single_image = Image.objects.get(category__slug=category_slug, title = title)
    except Exception as e:
        raise e

    context = {
        'single_image': single_image,
    }
    return render(request, 'gallery/image_detail.html', context)

def gallery(request, category_slug=None):
    categories = None
    images = None
    if category_slug != None:
        categories = get_object_or_404(Category, slug=category_slug)
        images = Image.objects.filter(category=categories)
        paginator = Paginator(images, 1)
        page = request.GET.get('page')
        paged_images = paginator.get_page(page)
        images_count = images.count()
    else:
        images = Image.objects.all()
        paginator = Paginator(images, 3)
        page = request.GET.get('page')
        paged_images = paginator.get_page(page)
        images_count = images.count()

    context = {
        'images': paged_images,
        'imagescount' : images_count
    }
    return render(request, 'gallery/image.html', context)

def upload_image(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            Image = form.save(commit=False)
            Image.uploaded_at = datetime.datetime.now()
            Image.uploaded_by = request.user
            Image.save()
            return redirect('upload_image')  # Redirect to a home page
    else:
        form = ImageForm()
    return render(request, 'gallery/upload_image.html', {'form': form})
