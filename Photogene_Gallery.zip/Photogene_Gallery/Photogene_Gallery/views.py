from django.shortcuts import render
from gallery.models import Image


def home(request):
    data = Image.objects.all();
    context = {
        'images_data': data
    }
    return render(request, 'home.html', context)
